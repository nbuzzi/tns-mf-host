export enum RolesByUserList {
  Basic = "Basic",
  Admin = "Admin",
  SuperUser = "SuperUser"
}

export enum Roles {
  Basic = "BASIC",
  Admin = "ADMIN",
  SuperUser = "SUPERUSER"
}
