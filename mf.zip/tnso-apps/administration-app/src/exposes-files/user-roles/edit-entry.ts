export { default } from '../../app/containers/user-roles/edit-user-roles/edit-user-roles';
