export { default } from '../views/menu/monitoring/devices/device-detail/DeviceDetail';
