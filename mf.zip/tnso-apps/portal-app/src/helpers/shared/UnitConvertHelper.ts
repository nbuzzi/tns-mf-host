export class UnitConvertHelper {
  static convertBytesToMegaBytes(bytes: number): number {
    return bytes / 1000000;
  }
}
