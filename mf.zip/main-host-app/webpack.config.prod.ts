export default require('./webpack.config');
