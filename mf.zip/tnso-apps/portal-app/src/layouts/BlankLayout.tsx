/* eslint-disable react/jsx-no-bind */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
import React from "react";
import { Outlet } from "react-router-dom";

const BlankLayout = () => <Outlet />;

export default BlankLayout;
