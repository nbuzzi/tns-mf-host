export { default } from '../../app/containers/user-roles/view-user-roles/view-user-role';
