export { default } from '../views/menu/administration/companyAdministration/CompanyProfile';
