import { env } from 'env';

export const environment = {
  ...env,
};
