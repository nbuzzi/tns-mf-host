import React from 'react';
import '../../../assets/scss/styledark.scss';
const DarkTheme = (): JSX.Element => {
  // eslint-disable-next-line react/jsx-no-useless-fragment
  return <></>;
};

export default DarkTheme;
