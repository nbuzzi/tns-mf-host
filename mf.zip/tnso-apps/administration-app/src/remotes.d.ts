declare module 'i18n-module/i18nModule';
declare module 'i18n-module/i18n';