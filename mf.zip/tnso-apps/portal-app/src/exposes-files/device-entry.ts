export { default } from '../views/menu/monitoring/devices/DevicesSection';
