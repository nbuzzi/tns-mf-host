export interface Note {
  note: string;
}
