const Text = 'MockedText';

export default Text;
