import { changeLanguage } from 'i18next';

const i18n = () => {
  return {
    changeLanguage: changeLanguage,
  };
};

export default i18n;
