const devicesStatus = require("./devicesStatus");

module.exports = {
  devicesStatus
};
