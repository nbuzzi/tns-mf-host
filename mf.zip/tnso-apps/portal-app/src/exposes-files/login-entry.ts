export { default } from "../views/auth/Login";
