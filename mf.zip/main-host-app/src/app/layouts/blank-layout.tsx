import React from 'react';
import { Outlet } from 'react-router-dom';

function BlankLayout(): JSX.Element {
  return <Outlet />;
}

export default BlankLayout;
