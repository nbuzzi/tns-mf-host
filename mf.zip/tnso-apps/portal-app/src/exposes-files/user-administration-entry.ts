export { default } from '../views/menu/administration/userAdministration/UserProfile';
